export const games = [
{
title:"Minecraft",
slug:"minecraft",
category:"Sandbox",
platform:"both",
playStore:"",
appStore:"",
image:""
},
{
title:"PUBG MOBILE",
slug:"pubg-mobile",
category:"Nişancı",
platform:"both",
playStore:"",
appStore:"",
image:""
},
{
title:"Genshin Impact",
slug:"genshin-impact",
category:"RPG",
platform:"both",
playStore:"",
appStore:"",
image:""
}
];
